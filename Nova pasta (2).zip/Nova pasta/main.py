Python 3.11.0 (main, Oct 24 2022, 18:26:48) [MSC v.1933 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
python bot.py
import discord
from discord.ext import commands
import random

# Configurar o bot com o prefixo '!'
bot = commands.Bot(command_prefix='!')

# Função de probabilidade para o jogo "Mines"
def play_mines():
    grid = ['💣'] * 25  # 25 bombs initially
    safe_spots = random.sample(range(25), 20)  # 20 safe spots
    for spot in safe_spots:
        grid[spot] = '💎'  # Replace bombs with diamonds
    return grid

# Exibir a grade de "Mines" (5x5)
def display_grid(grid):
    lines = []
    for i in range(5):
        line = grid[i*5:(i+1)*5]
        lines.append(' '.join(line))
    return '\n'.join(lines)

# Função de probabilidade para o Bac Bo
def play_bac_bo():
    outcomes = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅']
    player1 = random.choice(outcomes)
    player2 = random.choice(outcomes)
    banker1 = random.choice(outcomes)
    banker2 = random.choice(outcomes)

    player_score = outcomes.index(player1) + 1 + outcomes.index(player2) + 1
    banker_score = outcomes.index(banker1) + 1 + outcomes.index(banker2) + 1

    result = f"Player: {player1} {player2} - Score: {player_score}\nBanker: {banker1} {banker2} - Score: {banker_score}"
    if player_score > banker_score:
...         result += "\n🏆 *Player Wins!*"
...     elif banker_score > player_score:
...         result += "\n🏆 *Banker Wins!*"
...     else:
...         result += "\n🤝 *It's a Tie!*"
... 
...     return result
... 
... # Evento de inicialização
... @bot.event
... async def on_ready():
...     print(f'Bot connected as {bot.user}')
... 
... # Comando "!mines"
... @bot.command(name='mines')
... async def mines(ctx):
...     grid = play_mines()
...     displayed_grid = display_grid(grid)
...     await ctx.send(f'🎮 *Mines!*\n{displayed_grid}\n\nTry to find the diamonds without exploding!')
... 
... # Comando "!roulette"
... @bot.command(name='roulette')
... async def roulette(ctx):
...     colors = ['⚫ Black', '🔴 Red', '⚪ White']
...     weights = [18, 18, 1]  # Probabilities based on a real roulette wheel
...     suggested_color = random.choices(colors, weights=weights, k=1)[0]
...     message = f"🎯 ENTRY CONFIRMED!\nBET ON {suggested_color}\nPROTECTION ON ⚪ WHITE\n🤖 NO GREED BOT"
...     await ctx.send(message)
... 
... # Comando "!bacbo"
... @bot.command(name='bacbo')
... async def bacbo(ctx):
...     result = play_bac_bo()
...     await ctx.send(f"🎲 *Bac Bo Results!*\n{result}\n\nGood luck!")
... 
... # Rodar o bot
... bot.run('YOUR_TOKEN_HERE')
